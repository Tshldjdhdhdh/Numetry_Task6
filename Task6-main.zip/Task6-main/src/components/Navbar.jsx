
import React, { useState } from "react";
import LoginPage from "./Login"; 

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <nav className="bg-gray-800 text-white fixed w-full top-0 z-10 shadow-md">
      <div className="container mx-auto px-4 flex items-center justify-between h-16">
        <div className="text-2xl font-bold ml-8 flex items-center">
          <a href="#" className="hover:text-gray-300">Brand</a>
        </div>

        <div className="hidden md:flex space-x-28 items-center ">
          <a href="#home" className="hover:text-gray-300">Home</a>
          <a href="#about" className="hover:text-gray-300">About Us</a>
          <a href="#services" className="hover:text-gray-300">Services</a>
          <a href="#contact" className="hover:text-gray-300">Contact</a>

          <button
            className="ml-6 bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded-md transition duration-300"
            onClick={() => setIsModalOpen(true)}
          >
            Login
          </button>
        </div>

        <button
          className="md:hidden focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}
            />
          </svg>
        </button>
      </div>

      {isOpen && (
        <div className="md:hidden bg-gray-700 text-center py-2">
          <a href="#home" className="block px-4 py-2 hover:bg-gray-600">Home</a>
          <a href="#about" className="block px-4 py-2 hover:bg-gray-600">About Us</a>
          <a href="#services" className="block px-4 py-2 hover:bg-gray-600">Services</a>
          <a href="#contact" className="block px-4 py-2 hover:bg-gray-600">Contact</a>

          <button
            className="w-4/5 bg-blue-500 hover:bg-blue-600 text-black px-4 py-2 rounded-md mt-2"
            onClick={() => setIsModalOpen(true)}
          >
            Login
          </button>
        </div>
      )}

      <LoginPage isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </nav>
  );
};

export default Navbar;