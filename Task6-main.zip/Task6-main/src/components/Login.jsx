import React, { useState, useEffect } from "react";

const Login = ({ isOpen, onClose }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fade, setFade] = useState(false);  

  useEffect(() => {
    if (isOpen) {
      setFade(true); 
    } else {
      setFade(false); 
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const validateForm = () => {
    if (!email || !password) {
      setError("Please fill in both email and password.");
      return false;
    }

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailPattern.test(email)) {
      setError("Please enter a valid email.");
      return false;
    }

    setError(""); 
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;
  
    setIsSubmitting(true);
    // Simulate API call or further action
    setTimeout(() => {
      setIsSubmitting(false);
  
      // Check for correct password (For demonstration, hardcoded password check)
      if (password === "yourPassword") {
        alert("Login Successful!"); // Alert message on successful login
        onClose(); // Close modal after successful login
      } else {
        setError("Incorrect password."); // Show error message
      }
    }, 2000); // Simulate async login
  };
  

  return (
    <div className={`fixed inset-0 bg-gray-800 bg-opacity-75 flex items-center justify-center z-20 transition-opacity duration-500 ${fade ? 'opacity-100' : 'opacity-0'}`}>
      <div className="bg-white p-8 rounded-md shadow-md w-96 relative">
        <h2 className="text-3xl font-bold mb-6 text-center text-black">Login</h2> 
        <form onSubmit={handleSubmit}>
          {error && <p className="text-red-500 text-center mb-4">{error}</p>}

          <label className="block text-lg text-black font-medium mb-2" htmlFor="email">
            Email
          </label>
          <input
            type="email"
            id="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 mb-4 border-2 border-black rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
          />

          <label className="block text-lg text-black font-medium mb-2" htmlFor="password">
            Password
          </label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2 mb-4 border-2 border-black rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
          />

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-green-800 hover:bg-green-600 text-white px-4 py-2 rounded-md transition duration-300 disabled:bg-gray-400"
          >
            {isSubmitting ? "Logging in..." : "Login"}
          </button>
        </form>

        <div className="text-center mt-4">
          <a
            href="#"
            className="text-blue-500 hover:underline"
            onClick={() => alert("Redirecting to password recovery...")}
          >
            Forgot Password?
          </a>
        </div>

        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
        >
          ✕
        </button>
      </div>
    </div>
  );
};

export default Login;
